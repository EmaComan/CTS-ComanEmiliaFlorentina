package restaurant.observer.model;

public interface IClient {
    void primesteNotificare(String mesaj);
}
